# Introdução às Séries Temporais
Slides e códigos da aula 2 de Econometria Avançada - Séries Temporais na USJT.
